# Maison Christoffel — Chef's Menu App (Part 3: Final PoE)

> **Demo video (YouTube, Unlisted):** `PASTE YOUR LINK HERE`

## Part 3 change log (changes since Part 2)

All Part 2 screens, navigation and context were kept. Part 3 adds the following.

### New functionality
- **Manage menu items** — edit, update and delete (already in the Part 2 screens) now use the shared validation below, and every change shows immediately on all screens through `MenuContext`.
- **Search** — the search box now has a **clear (✕) button**.
- **Filter** — course chips now show **live counts** (e.g. `Mains (1)`), plus a "Showing X of Y dishes" line.
- **Clear search & filter** — new "Clear search & filter" link resets the search and the course filter in one tap; the "no results" message has a **Show all dishes** button.
- **Menu statistics** — now shown by default in a clearer **Menu Overview** panel (total dishes, average price, and count + average price per course). It can still be hidden.

### Refactoring (code quality)
- **New reusable components** (`src/components/`): `SearchBar`, `DishCard`, `EmptyState`, `StatsPanel`.
- **New reusable functions** (`src/utils/`): `validateDishForm`, `parsePrice` (`validation.ts`); `formatPrice`, `dishCount` (`format.ts`).
- The dish validation that was **duplicated in AddDishScreen and EditDishScreen is now one shared function**.
- `ChefMenuScreen` is shorter: the list row, search box, empty state and statistics were moved into components.
- Meaningful names and typed props on every new component.

### Dish photos (new)
- **Photo picker on Add and Edit** (`ImagePickerField`): choose a photo from the gallery, change it, or remove it. Uses `expo-image-picker`; install with `npx expo install expo-image-picker`. Dishes without a photo still show the letter placeholder.

### Validation & user-experience improvements
- Dish name max length (60), preparation notes min length (10 characters), price max (R10 000).
- Price accepts a **comma decimal** (`285,50`) and prices are shown consistently as `R285.00`.
- Decimal keyboard on the price field.
- Dishes without a photo show a **letter placeholder** instead of a blank box.
- Separate empty-state messages for "menu is empty" and "no search results".
- Accessibility labels on the search box, clear button and dish rows.

### Files added
`src/components/SearchBar.tsx`, `DishCard.tsx`, `EmptyState.tsx`, `StatsPanel.tsx`, `ImagePickerField.tsx`; `src/utils/validation.ts`, `format.ts`.
### Files edited
`ChefMenuScreen.tsx` (uses the new components, clear/filter additions), `AddDishScreen.tsx` and `EditDishScreen.tsx` (shared validation, decimal keyboard).
### Files unchanged
`App.tsx`, `SplashScreen.tsx`, `LoginScreen.tsx`, `ItemDetailsScreen.tsx`, `MenuContext.tsx`, `colors.ts`, `types/index.ts`, `navigation/types.ts`.

---

# Part 2 documentation (original)
A React Native (Expo + TypeScript) app for a fictional restaurant group, **Maison
Christoffel** (Cape Town • Franschhoek). Built for the MAST5112 POE: a chef can log in,
add dishes to a menu, browse/search/filter that menu, view a dish's full details, and
edit or delete it — with menu statistics summarised on the main screen.

## Tech stack

| Layer          | Choice                                              |
|----------------|------------------------------------------------------|
| Framework      | React Native via Expo (TypeScript template)          |
| Navigation     | `@react-navigation/native` + native-stack             |
| State          | React Context (`MenuContext`) — no backend required   |
| Form control   | `@react-native-picker/picker` for the course dropdown |
| Images         | Local `require()`'d assets in `assets/images/`        |

No backend or database is wired up — `MenuContext` holds the dish list in memory for
the lifetime of the app. That's intentional for this stage of the POE; swap it for
`AsyncStorage` or a real API if a later part requires persistence.

## Features (mapped to the rubric)

- **User Interface Design** — six screens, consistent dark-green/cream theme, serif
  headings, styled to match the brand mockups.
- **Search and Filter Menu Items** — `ChefMenuScreen` has a live text search (matches
  dish name) plus course filter chips (All / Starters / Mains / Desserts), combined
  with `useMemo` so filtering stays cheap as the list grows.
- **Display Menu Statistics** — a collapsible stats panel on `ChefMenuScreen` shows
  total dish count, overall average price, and a per-course breakdown (count + average
  price), computed by `getMenuStats()` in `MenuContext.tsx`.
- **Improve the User Experience** —
  - Required-field validation on both Add and Edit forms (name, notes, price > 0)
  - Inline error messages under each invalid field
  - Confirmation alert when a dish is successfully added or updated
  - A friendly empty-state message when there are no dishes yet, or none match the
    current search/filter
  - One shared theme (`src/theme/colors.ts`) keeps colors/spacing consistent across
    every screen

## Screens

| # | File                                | Purpose                                                             |
|---|--------------------------------------|----------------------------------------------------------------------|
| 1 | `src/screens/SplashScreen.tsx`       | Welcome/landing screen with restaurant photo and CTA button          |
| 2 | `src/screens/LoginScreen.tsx`        | Sign up / log in, with validation and toggling between modes         |
| 3 | `src/screens/AddDishScreen.tsx`      | Form to add a new dish (name, course dropdown, notes, price)         |
| 4 | `src/screens/ChefMenuScreen.tsx`     | Main list — search, course filter, stats panel, "Add New Dish" CTA   |
| 5 | `src/screens/ItemDetailsScreen.tsx`  | Full dish view ("Dish Dossier") with Edit / Delete / Back actions    |
| 6 | `src/screens/EditDishScreen.tsx`     | Pre-filled form to update or permanently delete an existing dish     |

## Project structure

```
MaisonChristoffel/
├── App.tsx                       # Navigation container + screen registry
├── assets/
│   └── images/                   # Restaurant + dish photos (see below)
└── src/
    ├── context/
    │   └── MenuContext.tsx       # Shared dish state: add/update/delete/get + stats
    ├── navigation/
    │   └── types.ts              # RootStackParamList (typed route params)
    ├── screens/
    │   ├── SplashScreen.tsx
    │   ├── LoginScreen.tsx
    │   ├── AddDishScreen.tsx
    │   ├── ChefMenuScreen.tsx
    │   ├── ItemDetailsScreen.tsx
    │   └── EditDishScreen.tsx
    ├── theme/
    │   └── colors.ts              # Shared color/font tokens
    └── types/
        └── index.ts               # Dish / Course types
```

## Images bundled in `assets/images/`

| File                          | Used on                          | Dish                  |
|--------------------------------|-----------------------------------|------------------------|
| `restaurant-interior.jpg`     | Splash screen hero                | —                      |
| `lamb-shank.jpg`              | Chef's Menu list + Item Details   | Braised Lamb Shank     |
| `pan-seared-kingklip.jpg`     | Chef's Menu list + Item Details   | Pan-Seared Kingklip    |
| `mango-panna-cotta.jpg`       | Chef's Menu list + Item Details   | Mango Panna Cotta      |

New dishes added through `AddDishScreen` currently have no photo (no image picker is
wired up yet) — they'll show the placeholder box until `expo-image-picker` is added.

## Setup — running this in VS Code

1. **Install prerequisites** — Node.js LTS from nodejs.org, and the Expo Go app on
   your phone (App Store / Play Store) for testing on a real device.
2. **Create a fresh Expo project**:
   ```bash
   npx create-expo-app MaisonChristoffel -t expo-template-blank-typescript
   cd MaisonChristoffel
   ```
3. **Install the extra packages these screens use**:
   ```bash
   npm install @react-navigation/native @react-navigation/native-stack \
     react-native-screens react-native-safe-area-context \
     @react-native-picker/picker
   ```
4. **Copy the provided files in** — copy this `src/` folder and `assets/` folder into
   your new project root, and overwrite the generated `App.tsx` with the one here.
5. **Open the project folder in VS Code** — File → Open Folder.
6. **Run it**:
   ```bash
   npx expo start
   ```
   Scan the QR code with Expo Go, or press `i` / `a` for a simulator/emulator.
7. **Edit and see live changes** — save any file and Expo's Fast Refresh updates the
   running app in a second or two.
8. **Push to GitHub for submission**:
   ```bash
   git init
   git add .
   git commit -m "Part 2 screens"
   ```
   then follow GitHub's "push an existing repository" instructions, and confirm the
   rubric wants the GitHub link (not a zip).

## Known limitations / next steps

- No image picker yet on Add/Edit — photos are hard-coded via `require()`.
- No persistence — closing the app resets the menu back to the three seed dishes.
- No authentication backend — `LoginScreen` validates input shape only, it doesn't
  check credentials against anything real.

---

---

# Full Source Code (current)

## `App.tsx`

```tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import type { RootStackParamList } from './src/navigation/types';

import { MenuProvider } from './src/context/MenuContext';
import SplashScreen from './src/screens/SplashScreen';
import LoginScreen from './src/screens/LoginScreen';
import ChefMenuScreen from './src/screens/ChefMenuScreen';
import AddDishScreen from './src/screens/AddDishScreen';
import ItemDetailsScreen from './src/screens/ItemDetailsScreen';
import EditDishScreen from './src/screens/EditDishScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <MenuProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Splash" screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Splash" component={SplashScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="ChefMenu" component={ChefMenuScreen} />
          <Stack.Screen name="AddDish" component={AddDishScreen} />
          <Stack.Screen name="ItemDetails" component={ItemDetailsScreen} />
          <Stack.Screen name="EditDish" component={EditDishScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </MenuProvider>
  );
}

```

## `src/components/DishCard.tsx`

```tsx
import React from 'react';
import { View, Text, Image, Pressable, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { Dish } from '../types';
import { formatPrice } from '../utils/format';

interface Props {
  dish: Dish;
  onPress: () => void;
}

/** One row in the Chef's Menu list. */
export default function DishCard({ dish, onPress }: Props) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${dish.name}, ${dish.course}, ${formatPrice(dish.price)}`}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.8 }]}
      onPress={onPress}
    >
      {dish.image ? (
        <Image source={dish.image} style={styles.thumb} resizeMode="cover" />
      ) : (
        // New dishes have no photo yet: show the first letter instead of a blank box.
        <View style={[styles.thumb, styles.placeholder]}>
          <Text style={styles.placeholderText}>{dish.name.charAt(0).toUpperCase()}</Text>
        </View>
      )}
      <View style={{ flex: 1 }}>
        <Text style={styles.course}>{dish.course.toUpperCase()}</Text>
        <Text style={styles.name}>{dish.name}</Text>
      </View>
      <Text style={styles.price}>{formatPrice(dish.price)}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  thumb: { width: 48, height: 48, borderRadius: 8, marginRight: 12 },
  placeholder: { backgroundColor: colors.offWhite, alignItems: 'center', justifyContent: 'center' },
  placeholderText: { color: colors.gold, fontSize: 20, fontWeight: '700' },
  course: { fontSize: 10, color: colors.subtext, letterSpacing: 1 },
  name: { fontSize: 15, color: colors.text, fontWeight: '600', marginTop: 2 },
  price: { fontSize: 14, color: colors.darkGreen, fontWeight: '700' },
});

```

## `src/components/EmptyState.tsx`

```tsx
import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import { colors, fonts } from '../theme/colors';

interface Props {
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}

export default function EmptyState({ title, message, actionLabel, onAction }: Props) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
      {actionLabel && onAction && (
        <Pressable style={styles.action} onPress={onAction} accessibilityRole="button">
          <Text style={styles.actionText}>{actionLabel}</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { alignItems: 'center', paddingTop: 40, paddingHorizontal: 20 },
  title: { fontSize: 18, fontFamily: fonts.heading, color: colors.text, marginBottom: 6 },
  message: { textAlign: 'center', color: colors.subtext, fontSize: 14, lineHeight: 20 },
  action: {
    marginTop: 18,
    backgroundColor: colors.darkGreen,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 10,
  },
  actionText: { color: colors.white, fontWeight: '600', fontSize: 14 },
});

```

## `src/components/ImagePickerField.tsx`

```tsx
import React from 'react';
import { View, Text, Image, Pressable, Alert, StyleSheet } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { colors } from '../theme/colors';
import { Dish } from '../types';

interface Props {
  value?: Dish['image'];
  onChange: (image: Dish['image']) => void;
}

/** Lets the chef choose a dish photo from the phone's gallery (optional). */
export default function ImagePickerField({ value, onChange }: Props) {
  const pickImage = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert(
        'Permission needed',
        'Allow photo access in your phone settings to add a dish photo.'
      );
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [4, 3],
      quality: 0.7,
    });

    if (!result.canceled && result.assets.length > 0) {
      onChange({ uri: result.assets[0].uri });
    }
  };

  return (
    <View>
      <Text style={styles.label}>Photo (optional)</Text>
      <Pressable
        style={styles.box}
        onPress={pickImage}
        accessibilityRole="button"
        accessibilityLabel={value ? 'Change dish photo' : 'Choose dish photo'}
      >
        {value ? (
          <Image source={value} style={styles.preview} resizeMode="cover" />
        ) : (
          <Text style={styles.placeholder}>Tap to choose a photo</Text>
        )}
      </Pressable>
      {value && (
        <View style={styles.actions}>
          <Pressable onPress={pickImage}>
            <Text style={styles.link}>Change photo</Text>
          </Pressable>
          <Pressable onPress={() => onChange(undefined)}>
            <Text style={[styles.link, { color: colors.danger }]}>Remove photo</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 12, color: colors.subtext, marginBottom: 6, marginTop: 14 },
  box: {
    height: 150,
    borderWidth: 1,
    borderColor: colors.border,
    borderStyle: 'dashed',
    borderRadius: 8,
    backgroundColor: colors.white,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  preview: { width: '100%', height: '100%' },
  placeholder: { color: colors.subtext, fontSize: 13 },
  actions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  link: { color: colors.darkGreen, fontSize: 13, fontWeight: '600' },
});

```

## `src/components/SearchBar.tsx`

```tsx
import React from 'react';
import { View, TextInput, Pressable, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';

interface Props {
  value: string;
  onChangeText: (text: string) => void;
}

/** Search box with a clear (✕) button. */
export default function SearchBar({ value, onChangeText }: Props) {
  return (
    <View style={styles.wrapper}>
      <TextInput
        style={styles.input}
        placeholder="Search dishes..."
        placeholderTextColor={colors.subtext}
        value={value}
        onChangeText={onChangeText}
        accessibilityLabel="Search dishes by name"
      />
      {value.length > 0 && (
        <Pressable
          onPress={() => onChangeText('')}
          hitSlop={10}
          accessibilityRole="button"
          accessibilityLabel="Clear search"
        >
          <Text style={styles.clear}>✕</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: colors.white,
    paddingHorizontal: 14,
    marginBottom: 12,
  },
  input: { flex: 1, paddingVertical: 10, fontSize: 14, color: colors.text },
  clear: { color: colors.subtext, fontSize: 16, paddingLeft: 8 },
});

```

## `src/components/StatsPanel.tsx`

```tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors, fonts } from '../theme/colors';
import { formatPrice, dishCount } from '../utils/format';

interface Props {
  stats: {
    totalItems: number;
    overallAvg: number;
    perCourse: { course: string; count: number; avgPrice: number }[];
  };
}

/** Menu overview: total dishes, average price, and a per-course breakdown. */
export default function StatsPanel({ stats }: Props) {
  return (
    <View style={styles.panel}>
      <Text style={styles.heading}>Menu Overview</Text>
      <View style={styles.tiles}>
        <View style={styles.tile}>
          <Text style={styles.tileValue}>{stats.totalItems}</Text>
          <Text style={styles.tileLabel}>Total dishes</Text>
        </View>
        <View style={styles.tile}>
          <Text style={styles.tileValue}>{formatPrice(stats.overallAvg)}</Text>
          <Text style={styles.tileLabel}>Average price</Text>
        </View>
      </View>
      {stats.perCourse.map((c) => (
        <View key={c.course} style={styles.row}>
          <Text style={styles.course}>{c.course}</Text>
          <Text style={styles.detail}>
            {dishCount(c.count)}
            {c.count > 0 ? `  •  avg ${formatPrice(c.avgPrice)}` : ''}
          </Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  panel: { backgroundColor: colors.offWhite, borderRadius: 10, padding: 14, marginBottom: 14 },
  heading: { fontSize: 16, fontFamily: fonts.heading, color: colors.text, marginBottom: 10 },
  tiles: { flexDirection: 'row', marginBottom: 8 },
  tile: {
    flex: 1,
    backgroundColor: colors.white,
    borderRadius: 8,
    padding: 12,
    marginRight: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  tileValue: { fontSize: 20, fontWeight: '700', color: colors.darkGreen },
  tileLabel: { fontSize: 11, color: colors.subtext, marginTop: 2 },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderTopWidth: 1,
    borderTopColor: colors.border,
  },
  course: { fontSize: 13, color: colors.text, fontWeight: '600' },
  detail: { fontSize: 13, color: colors.subtext },
});

```

## `src/context/MenuContext.tsx`

```tsx
import React, { createContext, useContext, useMemo, useState } from 'react';
import { Course, Dish } from '../types';

interface MenuContextValue {
  dishes: Dish[];
  addDish: (dish: Omit<Dish, 'id'>) => void;
  updateDish: (dish: Dish) => void;
  deleteDish: (id: string) => void;
  getDish: (id: string) => Dish | undefined;
}

const MenuContext = createContext<MenuContextValue | undefined>(undefined);

// A couple of starter items so the list/stats screens aren't empty on first run.
// Photos live in assets/images — swap these require() paths for your own shots any time.
const seedDishes: Dish[] = [
  {
    id: '1',
    name: 'Braised Lamb Shank',
    course: 'Mains',
    description:
      'Slow-braised lamb shank glazed in a red wine jus, finished with orange zest and chives, served over creamy potato gratin.',
    price: 285,
    image: require('../../assets/images/lamb-shank.jpg'),
  },
  {
    id: '2',
    name: 'Pan-Seared Kingklip',
    course: 'Starters',
    description:
      'Pan-seared kingklip over a fresh pea and herb puree with pearl couscous, finished with micro herbs.',
    price: 165,
    image: require('../../assets/images/pan-seared-kingklip.jpg'),
  },
  {
    id: '3',
    name: 'Mango Panna Cotta',
    course: 'Desserts',
    description:
      'Silky mango panna cotta with a tropical fruit salsa, tuile crisp, and a balsamic reduction.',
    price: 95,
    image: require('../../assets/images/mango-panna-cotta.jpg'),
  },
];

let nextId = seedDishes.length + 1;

export const MenuProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [dishes, setDishes] = useState<Dish[]>(seedDishes);

  const addDish = (dish: Omit<Dish, 'id'>) => {
    const newDish: Dish = { ...dish, id: String(nextId++) };
    setDishes((prev) => [...prev, newDish]);
  };

  const updateDish = (updated: Dish) => {
    setDishes((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
  };

  const deleteDish = (id: string) => {
    setDishes((prev) => prev.filter((d) => d.id !== id));
  };

  const getDish = (id: string) => dishes.find((d) => d.id === id);

  const value = useMemo(
    () => ({ dishes, addDish, updateDish, deleteDish, getDish }),
    [dishes]
  );

  return <MenuContext.Provider value={value}>{children}</MenuContext.Provider>;
};

export const useMenu = (): MenuContextValue => {
  const ctx = useContext(MenuContext);
  if (!ctx) throw new Error('useMenu must be used within a MenuProvider');
  return ctx;
};

// Helper used by the Chef's Menu screen to build the "Display Menu Statistics" section.
export const getMenuStats = (dishes: Dish[]) => {
  const totalItems = dishes.length;
  const courses: Course[] = ['Starters', 'Mains', 'Desserts'];

  const perCourse = courses.map((course) => {
    const items = dishes.filter((d) => d.course === course);
    const avgPrice =
      items.length > 0
        ? items.reduce((sum, d) => sum + d.price, 0) / items.length
        : 0;
    return { course, count: items.length, avgPrice };
  });

  const overallAvg =
    totalItems > 0 ? dishes.reduce((sum, d) => sum + d.price, 0) / totalItems : 0;

  return { totalItems, perCourse, overallAvg };
};

```

## `src/navigation/types.ts`

```tsx
export type RootStackParamList = {
  Splash: undefined;
  Login: undefined;
  ChefMenu: undefined;
  AddDish: undefined;
  ItemDetails: { dishId: string };
  EditDish: { dishId: string };
};

```

## `src/screens/AddDishScreen.tsx`

```tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';
import { COURSES, Course, Dish } from '../types';
import { useMenu } from '../context/MenuContext';
import { validateDishForm, parsePrice } from '../utils/validation';
import ImagePickerField from '../components/ImagePickerField';

type Props = NativeStackScreenProps<RootStackParamList, 'AddDish'>;

export default function AddDishScreen({ navigation }: Props) {
  const { addDish } = useMenu();

  const [name, setName] = useState('');
  const [course, setCourse] = useState<Course>('Starters');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [image, setImage] = useState<Dish['image']>(undefined);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const validate = () => {
    const next = validateDishForm({ name, course, description, price });
    setErrors(next as { [key: string]: string });
    return Object.keys(next).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;

    addDish({
      name: name.trim(),
      course,
      description: description.trim(),
      price: parsePrice(price),
      image,
    });

    // Confirmation when a menu item has been successfully added.
    Alert.alert('Dish Added', `${name.trim()} has been added to the Chef's Menu.`, [
      { text: 'OK', onPress: () => navigation.navigate('ChefMenu') },
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Add New Dish</Text>

        <Text style={styles.label}>Dish Name</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. Karoo Lamb Cutlets"
          placeholderTextColor={colors.subtext}
          value={name}
          onChangeText={setName}
        />
        {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

        <Text style={styles.label}>Course</Text>
        <View style={styles.pickerWrapper}>
          <Picker selectedValue={course} onValueChange={(value) => setCourse(value as Course)}>
            {COURSES.map((c) => (
              <Picker.Item key={c} label={c} value={c} />
            ))}
          </Picker>
        </View>

        <Text style={styles.label}>Preparation Notes</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Describe the dish, key ingredients and plating..."
          placeholderTextColor={colors.subtext}
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
        />
        {errors.description && <Text style={styles.errorText}>{errors.description}</Text>}

        <Text style={styles.label}>Price (R)</Text>
        <TextInput
          style={styles.input}
          placeholder="e.g. 285"
          placeholderTextColor={colors.subtext}
          value={price}
          onChangeText={setPrice}
          keyboardType="decimal-pad"
        />
        {errors.price && <Text style={styles.errorText}>{errors.price}</Text>}

        <ImagePickerField value={image} onChange={setImage} />

        <TouchableOpacity style={styles.saveButton} activeOpacity={0.85} onPress={handleSave}>
          <Text style={styles.saveButtonText}>Save Dish</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.goBack()}>
          <Text style={styles.cancelButtonText}>Cancel</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  container: { padding: 24, paddingBottom: 48 },
  heading: { fontSize: 24, fontFamily: fonts.heading, color: colors.text, marginBottom: 20 },
  label: { fontSize: 12, color: colors.subtext, marginBottom: 6, marginTop: 14 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    backgroundColor: colors.white,
    color: colors.text,
  },
  textArea: { height: 100, textAlignVertical: 'top' },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: colors.white,
    overflow: 'hidden',
  },
  errorText: { color: colors.danger, fontSize: 12, marginTop: 6 },
  saveButton: {
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 28,
  },
  saveButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  cancelButton: { alignItems: 'center', marginTop: 14 },
  cancelButtonText: { color: colors.subtext, fontSize: 13 },
});

```

## `src/screens/ChefMenuScreen.tsx`

```tsx
import React, { useMemo, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';
import { Course, Dish } from '../types';
import { getMenuStats, useMenu } from '../context/MenuContext';
import SearchBar from '../components/SearchBar';
import EmptyState from '../components/EmptyState';
import DishCard from '../components/DishCard';
import StatsPanel from '../components/StatsPanel';
import { dishCount } from '../utils/format';

type Props = NativeStackScreenProps<RootStackParamList, 'ChefMenu'>;

const FILTERS: Array<Course | 'All'> = ['All', 'Starters', 'Mains', 'Desserts'];

export default function ChefMenuScreen({ navigation }: Props) {
  const { dishes } = useMenu();
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState<Course | 'All'>('All');
  const [showStats, setShowStats] = useState(true); // stats visible by default

  // --- Search and Filter Menu Items ---
  const filteredDishes = useMemo(() => {
    return dishes.filter((d) => {
      const matchesCourse = activeFilter === 'All' || d.course === activeFilter;
      const matchesSearch = d.name.toLowerCase().includes(search.trim().toLowerCase());
      return matchesCourse && matchesSearch;
    });
  }, [dishes, search, activeFilter]);

  const stats = useMemo(() => getMenuStats(dishes), [dishes]);

  // --- Clear the search and filter to show every dish again ---
  const isFiltering = search.trim().length > 0 || activeFilter !== 'All';
  const clearFilters = () => {
    setSearch('');
    setActiveFilter('All');
  };

  const renderDish = ({ item }: { item: Dish }) => (
    <DishCard dish={item} onPress={() => navigation.navigate('ItemDetails', { dishId: item.id })} />
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <Text style={styles.heading}>Chef's Menu</Text>
        <TouchableOpacity onPress={() => setShowStats((s) => !s)}>
          <Text style={styles.statsToggle}>{showStats ? 'Hide Stats' : 'Show Stats'}</Text>
        </TouchableOpacity>
      </View>

      {/* --- Display Menu Statistics --- */}
      {showStats && <StatsPanel stats={stats} />}

      <SearchBar value={search} onChangeText={setSearch} />

      <View style={styles.filterRow}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, activeFilter === f && styles.filterChipActive]}
            onPress={() => setActiveFilter(f)}
          >
            <Text
              style={[
                styles.filterChipText,
                activeFilter === f && styles.filterChipTextActive,
              ]}
            >
              {f} ({f === 'All' ? dishes.length : dishes.filter((d) => d.course === f).length})
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.resultsRow}>
        <Text style={styles.resultsText}>
          Showing {filteredDishes.length} of {dishCount(dishes.length)}
        </Text>
        {isFiltering && (
          <TouchableOpacity onPress={clearFilters}>
            <Text style={styles.clearText}>Clear search & filter</Text>
          </TouchableOpacity>
        )}
      </View>

      {filteredDishes.length === 0 ? (
        // Suitable message when no menu items have been added / match the filters.
        <EmptyState
          title={dishes.length === 0 ? 'Your menu is empty' : 'No matching dishes'}
          message={
            dishes.length === 0
              ? 'No menu items have been added yet. Tap "Add New Dish" to get started.'
              : 'No dishes match your search or filter.'
          }
          actionLabel={dishes.length === 0 ? undefined : 'Show all dishes'}
          onAction={clearFilters}
        />
      ) : (
        <FlatList
          data={filteredDishes}
          keyExtractor={(item) => item.id}
          renderItem={renderDish}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      )}

      <TouchableOpacity
        style={styles.addButton}
        activeOpacity={0.85}
        onPress={() => navigation.navigate('AddDish')}
      >
        <Text style={styles.addButtonText}>+ Add New Dish</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream, paddingHorizontal: 20 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 12,
    marginBottom: 12,
  },
  heading: { fontSize: 24, fontFamily: fonts.heading, color: colors.text },
  statsToggle: { color: colors.darkGreen, fontSize: 13, fontWeight: '600' },
  filterRow: { flexDirection: 'row', marginBottom: 14 },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: colors.border,
    marginRight: 8,
  },
  filterChipActive: { backgroundColor: colors.darkGreen, borderColor: colors.darkGreen },
  filterChipText: { fontSize: 12, color: colors.text },
  filterChipTextActive: { color: colors.white },
  resultsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  resultsText: { fontSize: 12, color: colors.subtext },
  clearText: { fontSize: 12, color: colors.darkGreen, fontWeight: '600' },
  addButton: {
    position: 'absolute',
    left: 20,
    right: 20,
    bottom: 20,
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  addButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
});

```

## `src/screens/EditDishScreen.tsx`

```tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
  Alert,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';
import { COURSES, Course, Dish } from '../types';
import { useMenu } from '../context/MenuContext';
import { validateDishForm, parsePrice } from '../utils/validation';
import ImagePickerField from '../components/ImagePickerField';

type Props = NativeStackScreenProps<RootStackParamList, 'EditDish'>;

export default function EditDishScreen({ route, navigation }: Props) {
  const { dishId } = route.params;
  const { getDish, updateDish, deleteDish } = useMenu();
  const existing = getDish(dishId);

  const [name, setName] = useState(existing?.name ?? '');
  const [course, setCourse] = useState<Course>(existing?.course ?? 'Starters');
  const [description, setDescription] = useState(existing?.description ?? '');
  const [price, setPrice] = useState(existing ? String(existing.price) : '');
  const [image, setImage] = useState<Dish['image']>(existing?.image);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  if (!existing) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <Text style={styles.errorText}>This dish no longer exists.</Text>
          <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.navigate('ChefMenu')}>
            <Text style={styles.cancelButtonText}>Back to Menu</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const validate = () => {
    const next = validateDishForm({ name, course, description, price });
    setErrors(next as { [key: string]: string });
    return Object.keys(next).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    updateDish({
      id: existing.id,
      name: name.trim(),
      course,
      description: description.trim(),
      price: parsePrice(price),
      image, // keeps the current photo unless the chef changed or removed it
    });
    Alert.alert('Dish Updated', `${name.trim()} has been updated.`, [
      { text: 'OK', onPress: () => navigation.navigate('ItemDetails', { dishId: existing.id }) },
    ]);
  };

  const handleDelete = () => {
    Alert.alert('Delete Dish', `Permanently remove "${existing.name}"?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteDish(existing.id);
          navigation.navigate('ChefMenu');
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>Edit Menu Item</Text>

        <Text style={styles.label}>Dish Name</Text>
        <TextInput style={styles.input} value={name} onChangeText={setName} />
        {errors.name && <Text style={styles.errorText}>{errors.name}</Text>}

        <Text style={styles.label}>Course</Text>
        <View style={styles.pickerWrapper}>
          <Picker selectedValue={course} onValueChange={(value) => setCourse(value as Course)}>
            {COURSES.map((c) => (
              <Picker.Item key={c} label={c} value={c} />
            ))}
          </Picker>
        </View>

        <Text style={styles.label}>Preparation Notes</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
        />
        {errors.description && <Text style={styles.errorText}>{errors.description}</Text>}

        <Text style={styles.label}>Price (R)</Text>
        <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="decimal-pad" />
        {errors.price && <Text style={styles.errorText}>{errors.price}</Text>}

        <ImagePickerField value={image} onChange={setImage} />

        <TouchableOpacity style={styles.saveButton} activeOpacity={0.85} onPress={handleSave}>
          <Text style={styles.saveButtonText}>Save Changes</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.deleteButton} activeOpacity={0.85} onPress={handleDelete}>
          <Text style={styles.deleteButtonText}>Delete Dish</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.goBack()}>
          <Text style={styles.cancelButtonText}>Cancel</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  container: { padding: 24, paddingBottom: 48 },
  heading: { fontSize: 24, fontFamily: fonts.heading, color: colors.text, marginBottom: 20 },
  label: { fontSize: 12, color: colors.subtext, marginBottom: 6, marginTop: 14 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    backgroundColor: colors.white,
    color: colors.text,
  },
  textArea: { height: 100, textAlignVertical: 'top' },
  pickerWrapper: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    backgroundColor: colors.white,
    overflow: 'hidden',
  },
  errorText: { color: colors.danger, fontSize: 12, marginTop: 6 },
  saveButton: {
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 28,
  },
  saveButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  deleteButton: {
    backgroundColor: colors.danger,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  deleteButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  cancelButton: { alignItems: 'center', marginTop: 14 },
  cancelButtonText: { color: colors.subtext, fontSize: 13 },
});

```

## `src/screens/ItemDetailsScreen.tsx`

```tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, SafeAreaView, Alert, Image } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';
import { useMenu } from '../context/MenuContext';

type Props = NativeStackScreenProps<RootStackParamList, 'ItemDetails'>;

export default function ItemDetailsScreen({ route, navigation }: Props) {
  const { dishId } = route.params;
  const { getDish, deleteDish } = useMenu();
  const dish = getDish(dishId);

  if (!dish) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <Text style={styles.emptyText}>This dish could not be found. It may have been deleted.</Text>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.navigate('ChefMenu')}>
            <Text style={styles.backButtonText}>Back to Menu</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleDelete = () => {
    Alert.alert('Delete Dish', `Remove "${dish.name}" from the menu?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => {
          deleteDish(dish.id);
          navigation.navigate('ChefMenu');
        },
      },
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.navigate('ChefMenu')}>
          <Text style={styles.topBarLink}>{'< Menu'}</Text>
        </TouchableOpacity>
        <Text style={styles.topBarLabel}>DISH DOSSIER</Text>
        <View style={{ width: 50 }} />
      </View>

      {dish.image ? (
        <Image source={dish.image} style={styles.image} resizeMode="cover" />
      ) : (
        <View style={styles.image} />
      )}

      <View style={styles.container}>
        <Text style={styles.course}>{dish.course.toUpperCase()}</Text>
        <View style={styles.titleRow}>
          <Text style={styles.name}>{dish.name}</Text>
          <Text style={styles.price}>R{dish.price}</Text>
        </View>

        <Text style={styles.sectionLabel}>PREPARATION NOTES</Text>
        <Text style={styles.description}>{dish.description}</Text>
      </View>

      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.editButton}
          activeOpacity={0.85}
          onPress={() => navigation.navigate('EditDish', { dishId: dish.id })}
        >
          <Text style={styles.editButtonText}>Edit Item</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.deleteButton} activeOpacity={0.85} onPress={handleDelete}>
          <Text style={styles.deleteButtonText}>Delete Item</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.backButton} onPress={() => navigation.navigate('ChefMenu')}>
          <Text style={styles.backButtonText}>Back to Menu</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  topBarLink: { color: colors.darkGreen, fontSize: 14, fontWeight: '600' },
  topBarLabel: { fontSize: 11, letterSpacing: 2, color: colors.subtext },
  image: {
    height: 200,
    marginHorizontal: 20,
    borderRadius: 14,
    backgroundColor: colors.offWhite,
  },
  container: { padding: 20 },
  course: { fontSize: 11, letterSpacing: 2, color: colors.gold, marginBottom: 6 },
  titleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  name: { flex: 1, fontSize: 22, fontFamily: fonts.heading, color: colors.text, marginRight: 10 },
  price: { fontSize: 20, color: colors.darkGreen, fontWeight: '700' },
  sectionLabel: {
    fontSize: 11,
    letterSpacing: 1.5,
    color: colors.subtext,
    marginTop: 24,
    marginBottom: 8,
  },
  description: { fontSize: 14, color: colors.text, lineHeight: 21 },
  footer: { paddingHorizontal: 20, paddingBottom: 24, marginTop: 'auto' },
  editButton: {
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  editButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  deleteButton: {
    backgroundColor: colors.danger,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  deleteButtonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  backButton: { alignItems: 'center', paddingVertical: 6 },
  backButtonText: { color: colors.subtext, fontSize: 13 },
  emptyText: { textAlign: 'center', color: colors.subtext, fontSize: 14, marginBottom: 16 },
});

```

## `src/screens/LoginScreen.tsx`

```tsx
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = () => {
    // --- Validation for required fields + appropriate error messages ---
    if (!email.trim() || !password.trim()) {
      setError('Please fill in both email and password.');
      return;
    }
    const emailPattern = /\S+@\S+\.\S+/;
    if (!emailPattern.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setError(null);
    // In a full build, this is where you'd call your auth API.
    navigation.replace('ChefMenu');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.container}>
          <Text style={styles.heading}>{mode === 'login' ? 'Log In' : 'Sign Up'}</Text>
          <Text style={styles.subheading}>
            {mode === 'login'
              ? 'Welcome back to Maison Christoffel.'
              : 'Create a chef account to manage the menu.'}
          </Text>

          {error && <Text style={styles.errorText}>{error}</Text>}

          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="you@maisonchristoffel.com"
            placeholderTextColor={colors.subtext}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="••••••••"
            placeholderTextColor={colors.subtext}
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity style={styles.button} activeOpacity={0.85} onPress={handleSubmit}>
            <Text style={styles.buttonText}>{mode === 'login' ? 'Log In' : 'Create Account'}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              setError(null);
              setMode(mode === 'login' ? 'signup' : 'login');
            }}
          >
            <Text style={styles.switchText}>
              {mode === 'login'
                ? "Don't have an account? Sign up"
                : 'Already have an account? Log in'}
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  container: { flex: 1, paddingHorizontal: 24, justifyContent: 'center' },
  heading: { fontSize: 28, fontFamily: fonts.heading, color: colors.text, marginBottom: 6 },
  subheading: { fontSize: 14, color: colors.subtext, marginBottom: 20 },
  errorText: {
    color: colors.danger,
    backgroundColor: '#F8ECEC',
    padding: 10,
    borderRadius: 8,
    marginBottom: 16,
    fontSize: 13,
  },
  label: { fontSize: 12, color: colors.subtext, marginBottom: 6, marginTop: 12 },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 14,
    backgroundColor: colors.white,
    color: colors.text,
  },
  button: {
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  switchText: {
    textAlign: 'center',
    color: colors.darkGreen,
    marginTop: 16,
    fontSize: 13,
  },
});

```

## `src/screens/SplashScreen.tsx`

```tsx
import React from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../navigation/types';
import { colors, fonts } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Splash'>;

export default function SplashScreen({ navigation }: Props) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.heroImageWrapper}>
          <Image
            source={require('../../assets/images/restaurant-interior.jpg')}
            style={styles.heroImage}
          />
          <View style={styles.heroOverlay}>
            <Text style={styles.iconGlyph}>{'\u2694'}</Text>
            <Text style={styles.heroTitle}>Maison</Text>
            <Text style={styles.heroSubtitle}>CHRISTOFFEL</Text>
            <Text style={styles.heroLocation}>CAPE TOWN • FRANSCHHOEK</Text>
          </View>
        </View>

        <View style={styles.body}>
          <Text style={styles.welcomeHeading}>Welcome to Maison</Text>
          <Text style={styles.welcomeCopy}>
            Experience culinary excellence refined by French heritage and South African
            terroir.
          </Text>
        </View>

        <View style={styles.footer}>
          <TouchableOpacity
            style={styles.button}
            activeOpacity={0.85}
            onPress={() => navigation.navigate('Login')}
          >
            <Text style={styles.buttonText}>Explore Chef's Menu</Text>
          </TouchableOpacity>

          <View style={styles.dots}>
            <View style={[styles.dot, styles.dotActive]} />
            <View style={styles.dot} />
            <View style={styles.dot} />
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: colors.cream },
  container: { flex: 1, justifyContent: 'space-between' },
  heroImageWrapper: {
    height: '42%',
    margin: 20,
    borderRadius: 16,
    overflow: 'hidden',
  },
  heroImage: { ...StyleSheet.absoluteFillObject, resizeMode: 'cover' },
  heroOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGlyph: { color: colors.white, fontSize: 20, marginBottom: 8 },
  heroTitle: {
    color: colors.white,
    fontSize: 34,
    fontFamily: fonts.heading,
  },
  heroSubtitle: { color: colors.white, letterSpacing: 4, marginTop: 4, fontWeight: '600' },
  heroLocation: { color: colors.white, fontSize: 11, letterSpacing: 2, marginTop: 8 },
  body: { paddingHorizontal: 24 },
  welcomeHeading: {
    fontSize: 24,
    fontFamily: fonts.heading,
    color: colors.text,
    marginBottom: 10,
  },
  welcomeCopy: { fontSize: 14, color: colors.subtext, lineHeight: 20 },
  footer: { paddingHorizontal: 24, paddingBottom: 32 },
  button: {
    backgroundColor: colors.darkGreen,
    paddingVertical: 16,
    borderRadius: 10,
    alignItems: 'center',
  },
  buttonText: { color: colors.white, fontWeight: '600', fontSize: 15 },
  dots: { flexDirection: 'row', justifyContent: 'center', marginTop: 16 },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: colors.border,
    marginHorizontal: 3,
  },
  dotActive: { backgroundColor: colors.darkGreen, width: 16 },
});

```

## `src/theme/colors.ts`

```tsx
export const colors = {
  darkGreen: '#243B24',
  darkGreenPressed: '#1A2C1A',
  cream: '#FBFAF7',
  offWhite: '#F3F1EB',
  text: '#1E1E1E',
  subtext: '#6B6B63',
  border: '#DCD9CF',
  danger: '#8B2E2E',
  dangerPressed: '#6E2424',
  gold: '#B08D57',
  white: '#FFFFFF',
};

export const fonts = {
  // If you add custom fonts (e.g. via expo-font), swap these for the real family names.
  heading: 'serif',
  body: undefined, // undefined = system default
};

```

## `src/types/index.ts`

```tsx
export type Course = 'Starters' | 'Mains' | 'Desserts';

export const COURSES: Course[] = ['Starters', 'Mains', 'Desserts'];

export interface Dish {
  id: string;
  name: string;
  course: Course;
  description: string; // preparation notes
  price: number;
  image?: any; // result of require('../../assets/images/xyz.jpg'), or a { uri: string }
}

```

## `src/utils/format.ts`

```tsx
/** Formats a number as South African Rand, e.g. 285 -> "R285.00". */
export const formatPrice = (amount: number): string => `R${amount.toFixed(2)}`;

/** "1 dish" / "3 dishes" */
export const dishCount = (count: number): string => `${count} ${count === 1 ? 'dish' : 'dishes'}`;

```

## `src/utils/validation.ts`

```tsx
import type { Course } from '../types';

export type FormErrors<K extends string> = Partial<Record<K, string>>;

export interface DishFormValues {
  name: string;
  course: Course;
  description: string;
  price: string;
}

export const MAX_NAME_LENGTH = 60;
export const MIN_DESCRIPTION_LENGTH = 10;
export const MAX_PRICE = 10000;

/** Accepts "285", "285.50" and "285,50". */
export const parsePrice = (raw: string): number => Number(raw.trim().replace(',', '.'));

/** Shared by the Add and Edit screens (was duplicated in both in Part 2). */
export const validateDishForm = (
  values: DishFormValues
): FormErrors<'name' | 'description' | 'price'> => {
  const errors: FormErrors<'name' | 'description' | 'price'> = {};

  const name = values.name.trim();
  if (!name) errors.name = 'Dish name is required.';
  else if (name.length > MAX_NAME_LENGTH)
    errors.name = `Dish name must be ${MAX_NAME_LENGTH} characters or fewer.`;

  const description = values.description.trim();
  if (!description) errors.description = 'Preparation notes are required.';
  else if (description.length < MIN_DESCRIPTION_LENGTH)
    errors.description = `Please enter at least ${MIN_DESCRIPTION_LENGTH} characters.`;

  if (!values.price.trim()) {
    errors.price = 'Price is required.';
  } else {
    const price = parsePrice(values.price);
    if (isNaN(price) || price <= 0) errors.price = 'Enter a valid price greater than 0.';
    else if (price > MAX_PRICE) errors.price = `Price cannot be more than R${MAX_PRICE}.`;
  }
  return errors;
};

```
